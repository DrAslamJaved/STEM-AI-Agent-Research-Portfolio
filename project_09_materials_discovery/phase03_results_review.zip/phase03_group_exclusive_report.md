# Project 09: composition-diversity acquisition

Task: `matbench_expt_gap` | split mode: `group_exclusive` | folds: 5 | seeds: 2

The hybrid ranks bootstrap disagreement and distance to the closest labelled composition by percentile, then adds them with fixed equal weights. Distance uses the 118 element fractions. A positive gain means the hybrid has lower MAE at the same budget. Coverage is for nominal 90% split-conformal intervals.

| Labels | Random MAE | Uncertainty MAE | Hybrid MAE | Hybrid gain vs random (95% CI) | Hybrid gain vs uncertainty (95% CI) | Random / uncertainty / hybrid coverage |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 200 | 0.784 | 0.784 | 0.784 | +0.000 ([0.000, 0.000]) | +0.000 ([0.000, 0.000]) | 0.892 / 0.892 / 0.892 |
| 400 | 0.752 | 0.771 | 0.766 | -0.014 ([-0.038, 0.018]) | +0.005 ([-0.015, 0.025]) | 0.897 / 0.898 / 0.897 |
| 800 | 0.681 | 0.687 | 0.715 | -0.034 ([-0.047, -0.023]) | -0.029 ([-0.042, -0.020]) | 0.897 / 0.904 / 0.894 |
| 1600 | 0.608 | 0.611 | 0.614 | -0.006 ([-0.018, 0.010]) | -0.003 ([-0.013, 0.010]) | 0.895 / 0.904 / 0.899 |

## Threshold: 0.600 eV MAE

Runs crossing at a scheduled budget (out of 10): random 5; uncertainty 4; uncertainty_diversity 1.

Hybrid vs random: both crossed in 1 paired runs; median label saving 0 (range 0 to 0).
Hybrid vs uncertainty: both crossed in 1 paired runs; median label saving 0 (range 0 to 0).

## Interpretation

This filtered training set is a robustness analysis, not an official Matbench score.

Uncrossed runs remain in the crossing counts; label savings include only pairs where both crossed. A five-fold bootstrap interval is descriptive and imprecise. Acquisition is retrospective: no new material was synthesized.
